export PYTHONPATH=../../python:$PYTHONPATH
python example.py