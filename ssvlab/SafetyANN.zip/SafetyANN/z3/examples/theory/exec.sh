export LD_LIBRARY_PATH=../../lib:$LD_LIBRARY_PATH
./test_user_theory
