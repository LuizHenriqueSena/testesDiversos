gcc -fopenmp -o test_user_theory test_user_theory.c -I ../../include -L ../../lib -lz3
