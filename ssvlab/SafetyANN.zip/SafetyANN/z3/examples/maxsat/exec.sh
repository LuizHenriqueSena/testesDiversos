export LD_LIBRARY_PATH=../../lib:$LD_LIBRARY_PATH
./maxsat $1
